from django.shortcuts import render, redirect
from .models import TravelBucketList
from .forms import TravelBucketListForm


# Create your views here.

def index(request):
    travel_bucket_lists = TravelBucketList.objects.all()
    context = {
        'travel_bucket_lists': travel_bucket_lists
    }
    return render(request, 'buckets/index.html', context)


def about(request):
    return render(request, 'buckets/about.html')


def detail(request, bucket_pk):
    bucket_item = TravelBucketList.objects.get(pk=bucket_pk)
    context = {
        'bucket_item': bucket_item
    }
    return render(request, 'buckets/detail.html', context)


def create(request):
    if request.method == 'POST':
        form = TravelBucketListForm(request.POST, request.FILES)
        # form에는 POST로 요청받은 것에 추가하여 파일 역시 같이 저장해줘야 이미지가 정상적으로 등록된다.
        if form.is_valid():
            travel_bucket_list_item = form.save()
            return redirect('buckets:detail', travel_bucket_list_item.pk)
    else:
        form = TravelBucketListForm()
    context = {
        'form': form
    }
    return render(request, 'buckets/create.html', context)


def update(request, bucket_pk):
    bucket_item = TravelBucketList.objects.get(pk=bucket_pk)
    if request.method == 'POST':
        form = TravelBucketListForm(request.POST, request.FILES, instance=bucket_item)
        # instance에 해당 pk의 데이터만 할당하여 새로운 데이터가 아닌 기존 pk에 해당되는 데이터를 업데이트 할 수 있도록 함.
        if form.is_valid():
            travel_bucket_list_item = form.save()
            return redirect('buckets:detail', travel_bucket_list_item.pk)
    else:
        form = TravelBucketListForm(instance=bucket_item)
    context = {
        'bucket_item': bucket_item,
        'form': form
    }
    return render(request, 'buckets/update.html', context)


def delete(request, bucket_pk):
    bucket_item = TravelBucketList.objects.get(pk=bucket_pk)
    if request.method == 'POST':
        bucket_item.delete()
        return redirect('buckets:index')
        # method가 POST일 경우에만 해당 데이터 삭제 후 index페이지로 redirect
    return redirect('buckets:detail', bucket_pk)
        # method가 POST가 아닐경우 pk에 해당되는 데이터의 detail 페이지로 redirect
