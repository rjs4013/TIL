### 문제 10. (서술형) Django의 Form과 ModelForm의 차이점을 설명하고, 각각 어떤 상황에서 사용하는 것이 적절한지 서술하시오.
- 차이점 : Form은 해당 모델에서 필요한 필드를 modelclass에서 하나씩 할당해 저장하는 것이고, ModelForm은 modelclass 전체를 form으로 가져와 사용하는 것이다.

- 상황별 사용 : Form은 데이터의 검색, 조회 등 변경 사항이 없을 때에 사용하는 것이 적절하고, ModelForm은 데이터의 생성, 수정 등 변경 사항이 생길 때 사용하는 것이 적절하다.



### 문제 11. (서술형) Django의 MTV 패턴을 기반하여 HTTP 요청 응답이 반환되기까지의 흐름을 서술하시오.
- 특정 Url이 호출되면 그에 해당되는 View 함수를 호출한다. 해당 view 함수는 Modelclass 에서 필요한 객체를 받아들인 후, 필요한 Template을 렌더링 하여 HTTP 요청 응답이 반환된다. 렌더링 될 Template은 Modelclass에 작성된 요소 중 필요한 부분을 반영할 수 있다. 
