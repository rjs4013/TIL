-- 공통
CREATE TABLE articles(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title VARCHAR(100) NOT NULL,
  content TEXT NOT NULL,
  created_at DATE NOT NULL
);


SELECT * FROM articles;
DROP TABLE articles;
PRAGMA table_info('articles');


-- 1. Insert data into table
INSERT INTO articles (title, content, created_at)
VALUES ('제목', '내용', '2000-01-01');

INSERT INTO articles (title, content, created_at)
VALUES 
('제목1', '내용1', '2000-01-01'),
('제목2', '내용2', '2000-01-02'),
('제목3', '내용3', '2000-01-03');

INSERT INTO articles (title, content, created_at)
VALUES ('mytitle', 'mycontent', DATE())

-- 2. Update data in table
UPDATE articles
SET title = 'UPDATE TITLE', content = 'UPDATE CONTENT'
WHERE id = 2;

-- 3. Delete data from table
DELETE FROM articles
WHERE
  id IN(
    SELECT id FROM articles
    ORDER BY created_at
    LIMIT 2
  );