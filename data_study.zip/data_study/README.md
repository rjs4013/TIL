# SSAFY 12기 Database 라이브 자료

| 진행일 | 주제                     |
| ------ | ------------------------ |
| 10/10  | SQL   |
| 10/11  | Many to one relationships          |
| 10/14  | Many to many relationships 01              |
| 10/15  | Many to many relationships 02              |
